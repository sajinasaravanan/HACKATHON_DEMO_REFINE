from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple

from app.domain.models import ProjectState, Resource, WorkItem, Blocker, SprintActual, WorkItemStatus
from app.engines.metrics_engine import MetricsEngine, ProjectMetrics
from app.engines.dependency_engine import DependencyGraphEngine, DependencyDAG
from app.engines.critical_path_engine import CriticalPathEngine, CriticalPathResult
from app.engines.spillover_engine import SpilloverAnalysisEngine, SpilloverAnalysis
from app.engines.forecast_engine import ForecastEngine, ForecastResult
from app.engines.monte_carlo_engine import MonteCarloEngine, MonteCarloResult
from app.engines.impact_scoring_engine import ImpactScoringEngine, RiskScores
from app.engines.risk_engine import RiskEngine, RiskResult
from app.api.models_phase3 import (
    RecommendationType,
)


class RecommendationError(Exception):
    pass


@dataclass
class RecommendationCandidate:
    recommendation_id: str
    type: RecommendationType
    action: str
    target_ids: List[str]
    details: Dict[str, Any]
    reason: str
    implementation_effort: str
    confidence: str
    priority_score: float = 0.0
    baseline_probability: float = 0.0
    baseline_delay_days: float = 0.0
    baseline_risk_score: float = 0.0
    after_probability: float = 0.0
    after_delay_days: float = 0.0
    after_risk_score: float = 0.0
    expected_probability_gain: float = 0.0
    expected_delay_gain_days: float = 0.0
    expected_risk_reduction: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "recommendation_id": self.recommendation_id,
            "type": self.type.value,
            "action": self.action,
            "target_ids": self.target_ids,
            "details": self.details,
            "reason": self.reason,
            "implementation_effort": self.implementation_effort,
            "confidence": self.confidence,
            "priority_score": round(self.priority_score, 2),
            "baseline_probability": round(self.baseline_probability, 4),
            "baseline_delay_days": round(self.baseline_delay_days, 2),
            "baseline_risk_score": round(self.baseline_risk_score, 2),
            "after_probability": round(self.after_probability, 4),
            "after_delay_days": round(self.after_delay_days, 2),
            "after_risk_score": round(self.after_risk_score, 2),
            "expected_probability_gain": round(self.expected_probability_gain, 4),
            "expected_delay_gain_days": round(self.expected_delay_gain_days, 2),
            "expected_risk_reduction": round(self.expected_risk_reduction, 2),
        }


class RecommendationEngine:
    def __init__(
        self,
        project_state: ProjectState,
        metrics: ProjectMetrics,
        cp_result: CriticalPathResult,
        dag: DependencyDAG,
        spillover: SpilloverAnalysis,
        forecast: ForecastResult,
        monte_carlo: MonteCarloResult,
        risk_result: RiskResult,
        simulation_count: int = 1000,
    ):
        self.project_state = project_state
        self.metrics = metrics
        self.cp_result = cp_result
        self.dag = dag
        self.spillover = spillover
        self.forecast = forecast
        self.monte_carlo = monte_carlo
        self.risk_result = risk_result
        self.impact_scores = ImpactScoringEngine(project_state, dag).score()
        self.simulation_count = simulation_count
        self.work_items = {wi.item_id: wi for wi in project_state.work_items}
        self.resources = {r.resource_id: r for r in project_state.team}
        self.blockers = [b for b in project_state.blockers if not b.actual_resolution_date]
        self.current_sprint = self._find_current_sprint()
        self.recommendation_counter = 0
        self.baseline_metrics = self._baseline_summary()
        self._cached_candidates: List[RecommendationCandidate] = []

    def generate_recommendations(self) -> List[RecommendationCandidate]:
        candidates: List[RecommendationCandidate] = []

        candidates.extend(self._generate_blocker_recommendations())
        candidates.extend(self._generate_resource_recommendations())
        candidates.extend(self._generate_reassignment_recommendations())
        candidates.extend(self._generate_descope_recommendations())
        candidates.extend(self._generate_split_task_recommendations())
        candidates.extend(self._generate_cp_optimization_recommendations())

        for candidate in candidates:
            candidate.baseline_probability = self.baseline_metrics["probability"]
            candidate.baseline_delay_days = self.baseline_metrics["delay_days"]
            candidate.baseline_risk_score = self.baseline_metrics["risk_score"]
            self._simulate_candidate(candidate)
            self._score_candidate(candidate)

        result = sorted(candidates, key=lambda c: c.priority_score, reverse=True)
        self._cached_candidates = result
        return result

    def simulate_recommendation(self, recommendation_id: str) -> RecommendationCandidate:
        candidate = self._find_candidate_by_id(recommendation_id)
        if not candidate:
            raise RecommendationError(f"Recommendation {recommendation_id} not found")
        candidate.baseline_probability = self.baseline_metrics["probability"]
        candidate.baseline_delay_days = self.baseline_metrics["delay_days"]
        candidate.baseline_risk_score = self.baseline_metrics["risk_score"]
        self._simulate_candidate(candidate)
        self._score_candidate(candidate)
        return candidate

    def simulate_scenario(self, recommendation_ids: List[str]) -> Dict[str, Any]:
        baseline = self._baseline_summary()
        clone = self.project_state.model_copy(deep=True)
        for rec_id in recommendation_ids:
            candidate = self._find_candidate_by_id(rec_id)
            if not candidate:
                raise RecommendationError(f"Recommendation {rec_id} not found")
            self._apply_candidate(clone, candidate)

        summary = self._recalculate_summary(clone)
        return {
            "baseline": baseline,
            "scenario": summary,
            "recommendation_ids": recommendation_ids,
            "probability_gain": round(summary["probability"] - baseline["probability"], 4),
            "delay_reduction": round(baseline["delay_days"] - summary["delay_days"], 2),
            "risk_reduction": round(baseline["risk_score"] - summary["risk_score"], 2),
        }

    # ------------------------------------------------------------------
    # Candidate generation
    # ------------------------------------------------------------------
    def _generate_blocker_recommendations(self) -> List[RecommendationCandidate]:
        candidates: List[RecommendationCandidate] = []
        if not self.blockers:
            return candidates

        for blocker in sorted(
            self.blockers,
            key=lambda b: self._blocker_priority(b),
            reverse=True,
        )[:2]:
            target_ids = [blocker.blocker_id]
            reason = self._blocker_reason(blocker)
            action = f"Resolve blocker {blocker.blocker_id} first"
            candidates.append(
                RecommendationCandidate(
                    recommendation_id=self._next_id(),
                    type=RecommendationType.RESOLVE_BLOCKER,
                    action=action,
                    target_ids=target_ids,
                    details={
                        "blocker_id": blocker.blocker_id,
                        "severity": blocker.severity.value,
                        "affected_items": blocker.impacted_item_ids,
                    },
                    reason=reason,
                    implementation_effort="Low",
                    confidence="High",
                )
            )
        return candidates

    def _generate_resource_recommendations(self) -> List[RecommendationCandidate]:
        candidates: List[RecommendationCandidate] = []
        demand_by_skill = self._build_skill_demand()
        capacity_by_skill = self._build_skill_capacity()

        if not demand_by_skill:
            return candidates

        bottlenecks = []
        for skill, demand in demand_by_skill.items():
            capacity = capacity_by_skill.get(skill, 0.0)
            ratio = demand / max(capacity, 1.0)
            bottlenecks.append((ratio, skill, demand, capacity))

        bottlenecks.sort(reverse=True)
        top_ratio, top_skill, top_demand, top_capacity = bottlenecks[0]
        if top_ratio > 1.1:
            resource_role = self._suggest_role_for_skill(top_skill)
            action = f"Add {resource_role} with {top_skill} skill"
            reason = (
                f"{top_skill} demand is {top_demand:.1f}h while available matching capacity is only "
                f"{top_capacity:.1f}h. This creates a skill bottleneck."
            )
            candidates.append(
                RecommendationCandidate(
                    recommendation_id=self._next_id(),
                    type=RecommendationType.ADD_RESOURCE,
                    action=action,
                    target_ids=[],
                    details={
                        "role": resource_role,
                        "skill": top_skill,
                        "demand_hours": round(top_demand, 1),
                        "capacity_hours": round(top_capacity, 1),
                    },
                    reason=reason,
                    implementation_effort="Medium",
                    confidence="Medium",
                )
            )
        return candidates

    def _generate_reassignment_recommendations(self) -> List[RecommendationCandidate]:
        candidates: List[RecommendationCandidate] = []
        for item in self.project_state.work_items:
            if item.status == item.status.COMPLETED:
                continue
            if not item.assigned_resource:
                continue
            assigned = self.resources.get(item.assigned_resource)
            if not assigned:
                continue
            required_skill = item.required_skill
            if required_skill in {assigned.primary_skill, assigned.secondary_skill}:
                continue

            match = self._find_alternate_resource(required_skill, item.assigned_resource)
            if not match:
                continue
            action = (
                f"Reassign {item.item_id} from {assigned.name} to {match.name}"
            )
            reason = (
                f"{item.item_id} requires {required_skill} but is assigned to {assigned.name} "
                f"whose skills are {assigned.primary_skill}/{assigned.secondary_skill}. "
                f"{match.name} has matching skill and available capacity."
            )
            candidates.append(
                RecommendationCandidate(
                    recommendation_id=self._next_id(),
                    type=RecommendationType.REASSIGN_WORK,
                    action=action,
                    target_ids=[item.item_id],
                    details={
                        "from": assigned.name,
                        "to": match.name,
                        "skill": required_skill,
                    },
                    reason=reason,
                    implementation_effort="Low",
                    confidence="High",
                )
            )
            if len(candidates) >= 2:
                break
        return candidates

    def _generate_descope_recommendations(self) -> List[RecommendationCandidate]:
        candidates: List[RecommendationCandidate] = []
        scored_items: List[Tuple[float, WorkItem]] = []
        for item in self.project_state.work_items:
            if item.status != item.status.NOT_STARTED:
                continue
            if item.item_id in self.cp_result.items_on_critical_path:
                continue
            if item.priority == item.priority.CRITICAL:
                continue

            score = self._descope_score(item)
            scored_items.append((score, item))

        scored_items.sort(reverse=True, key=lambda x: x[0])
        for score, item in scored_items[:2]:
            action = f"Descope work item {item.item_id}"
            reason = (
                f"{item.item_id} is not started, low priority, not on the critical path, and has "
                f"{item.current_estimate_hrs:.1f}h effort. Removing it reduces remaining scope."
            )
            candidates.append(
                RecommendationCandidate(
                    recommendation_id=self._next_id(),
                    type=RecommendationType.DESCOPE_WORK,
                    action=action,
                    target_ids=[item.item_id],
                    details={
                        "item_id": item.item_id,
                        "priority": item.priority.value,
                        "estimate_hours": item.current_estimate_hrs,
                    },
                    reason=reason,
                    implementation_effort="Low",
                    confidence="High",
                )
            )
        return candidates

    def _generate_split_task_recommendations(self) -> List[RecommendationCandidate]:
        scored_items: List[Tuple[float, WorkItem]] = []
        for item in self.project_state.work_items:
            if item.status in {item.status.COMPLETED, item.status.DONE}:
                continue
            if item.current_estimate_hrs < 40.0:
                continue
            score = self._split_candidate_score(item)
            scored_items.append((score, item))

        scored_items.sort(reverse=True, key=lambda x: x[0])
        candidates: List[RecommendationCandidate] = []
        for score, item in scored_items[:2]:
            splits = max(1, int(item.current_estimate_hrs / 40.0))
            action = f"Split task {item.item_id} into {splits + 1} subtasks"
            reason = (
                f"{item.item_id} is a large {item.current_estimate_hrs:.1f}h task on the critical path. "
                f"Splitting it can reduce serial execution and improve schedule predictability."
            )
            candidates.append(
                RecommendationCandidate(
                    recommendation_id=self._next_id(),
                    type=RecommendationType.SPLIT_TASK,
                    action=action,
                    target_ids=[item.item_id],
                    details={
                        "item_id": item.item_id,
                        "estimate_hours": item.current_estimate_hrs,
                        "recommended_splits": splits,
                    },
                    reason=reason,
                    implementation_effort="Medium",
                    confidence="Medium",
                )
            )
        return candidates

    def _generate_cp_optimization_recommendations(self) -> List[RecommendationCandidate]:
        items = [
            self.work_items[item_id]
            for item_id in self.cp_result.items_on_critical_path
            if item_id in self.work_items and self.work_items[item_id].status != self.work_items[item_id].status.COMPLETED
        ]
        if not items:
            return []

        items.sort(key=lambda wi: wi.remaining_effort_hrs, reverse=True)
        top_items = items[:3]
        action = f"Optimize critical path items: {', '.join(i.item_id for i in top_items)}"
        reason = (
            f"These critical path items represent the largest remaining work on the schedule and are highest risk. "
            f"Targeting them can reduce the overall project delay."
        )
        return [
            RecommendationCandidate(
                recommendation_id=self._next_id(),
                type=RecommendationType.CRITICAL_PATH_OPTIMIZATION,
                action=action,
                target_ids=[i.item_id for i in top_items],
                details={
                    "critical_items": [i.item_id for i in top_items],
                    "total_remaining_hours": sum(i.remaining_effort_hrs for i in top_items),
                },
                reason=reason,
                implementation_effort="Medium",
                confidence="Medium",
            )
        ]

    # ------------------------------------------------------------------
    # Simulation helpers
    # ------------------------------------------------------------------
    def _simulate_candidate(self, candidate: RecommendationCandidate) -> None:
        clone = self.project_state.model_copy(deep=True)
        self._apply_candidate(clone, candidate)
        result = self._recalculate_summary(clone)
        candidate.after_probability = result["probability"]
        candidate.after_delay_days = result["delay_days"]
        candidate.after_risk_score = result["risk_score"]
        candidate.expected_probability_gain = round(
            candidate.after_probability - candidate.baseline_probability, 4
        )
        candidate.expected_delay_gain_days = round(
            candidate.baseline_delay_days - candidate.after_delay_days, 2
        )
        candidate.expected_risk_reduction = round(
            candidate.baseline_risk_score - candidate.after_risk_score, 2
        )

    def _apply_candidate(self, clone: ProjectState, candidate: RecommendationCandidate) -> None:
        if candidate.type == RecommendationType.RESOLVE_BLOCKER:
            self._apply_resolve_blocker(clone, candidate)
        elif candidate.type == RecommendationType.ADD_RESOURCE:
            self._apply_add_resource(clone, candidate)
        elif candidate.type == RecommendationType.REASSIGN_WORK:
            self._apply_reassign_work(clone, candidate)
        elif candidate.type == RecommendationType.DESCOPE_WORK:
            self._apply_descope_work(clone, candidate)
        elif candidate.type == RecommendationType.SPLIT_TASK:
            self._apply_split_task(clone, candidate)
        elif candidate.type == RecommendationType.CRITICAL_PATH_OPTIMIZATION:
            self._apply_critical_path_optimization(clone, candidate)
        else:
            raise RecommendationError(f"Unsupported recommendation type: {candidate.type}")

    def _recalculate_summary(self, state: ProjectState) -> Dict[str, float]:
        metrics = MetricsEngine(state).calculate()
        dag = DependencyGraphEngine(state).build_dag()
        cp_result = CriticalPathEngine(state, dag).analyze()
        spillover = SpilloverAnalysisEngine(state, metrics.average_item_effort).analyze()
        forecast = ForecastEngine(state, metrics, cp_result, spillover).calculate()
        monte_carlo = MonteCarloEngine(
            project_state=state,
            metrics=metrics,
            cp_result=cp_result,
            spillover=spillover,
            simulation_count=self.simulation_count,
        ).calculate()
        impact_scores = ImpactScoringEngine(state, dag).score()
        risk_result = RiskEngine(
            project_state=state,
            metrics=metrics,
            cp_result=cp_result,
            dag=dag,
            spillover=spillover,
            forecast=forecast,
            monte_carlo=monte_carlo,
            impact_scores=impact_scores,
        ).analyze()
        return {
            "probability": monte_carlo.on_time_probability,
            "delay_days": forecast.expected_delay_days,
            "risk_score": risk_result.overall_risk_score,
        }

    def _baseline_summary(self) -> Dict[str, float]:
        return {
            "probability": self.monte_carlo.on_time_probability,
            "delay_days": self.forecast.expected_delay_days,
            "risk_score": self.risk_result.overall_risk_score,
        }

    # ------------------------------------------------------------------
    # Virtual change implementations
    # ------------------------------------------------------------------
    def _apply_resolve_blocker(self, clone: ProjectState, candidate: RecommendationCandidate) -> None:
        if not candidate.target_ids:
            return
        blocker_id = candidate.target_ids[0]
        matching = [b for b in clone.blockers if b.blocker_id == blocker_id]
        if not matching:
            return
        blocker = matching[0]
        blocker.status = blocker.status.RESOLVED
        blocker.actual_resolution_date = datetime.utcnow()

    def _apply_add_resource(self, clone: ProjectState, candidate: RecommendationCandidate) -> None:
        skill = candidate.details.get("skill")
        role = candidate.details.get("role") or "Engineer"
        new_resource_id = f"RECR-{len(clone.team)+1}"
        clone.team.append(
            Resource(
                resource_id=new_resource_id,
                name=f"Recommended {role}",
                role=role,
                primary_skill=skill or "General",
                secondary_skill=None,
                skill_level=self._find_best_skill_level(skill),
                allocation_pct=0.1,
                availability_pct=1.0,
            )
        )
        # New resource already appended above as availability_pct=1.0, allocation_pct=0.1
        # Increase allocation to reflect full contribution
        new_resource = clone.team[-1]
        new_resource.allocation_pct = min(1.0, new_resource.allocation_pct + 0.9)

    def _apply_reassign_work(self, clone: ProjectState, candidate: RecommendationCandidate) -> None:
        if not candidate.target_ids:
            return
        item_id = candidate.target_ids[0]
        item = next((wi for wi in clone.work_items if wi.item_id == item_id), None)
        if not item:
            return
        to_name = candidate.details.get("to")
        if not to_name:
            return
        new_resource = next((r for r in clone.team if r.name == to_name), None)
        old_resource = next((r for r in clone.team if r.resource_id == item.assigned_resource), None)
        if new_resource:
            item.assigned_resource = new_resource.resource_id
            if old_resource:
                old_resource.allocation_pct = max(0.0, old_resource.allocation_pct - 0.1)
            new_resource.allocation_pct = min(1.0, new_resource.allocation_pct + 0.1)

    def _apply_descope_work(self, clone: ProjectState, candidate: RecommendationCandidate) -> None:
        if not candidate.target_ids:
            return
        for item_id in candidate.target_ids:
            item = next((wi for wi in clone.work_items if wi.item_id == item_id), None)
            if item:
                item.remaining_effort_hrs = 0.0
                item.current_estimate_hrs = 0.0
                item.status = item.status.COMPLETED
                item.is_scope_changed = True
                item.scope_change_reason = "Recommendation-based descope"

    def _apply_split_task(self, clone: ProjectState, candidate: RecommendationCandidate) -> None:
        if not candidate.target_ids:
            return
        item_id = candidate.target_ids[0]
        item = next((wi for wi in clone.work_items if wi.item_id == item_id), None)
        if not item:
            return
        reduction = item.current_estimate_hrs * 0.20
        item.current_estimate_hrs = max(1.0, item.current_estimate_hrs - reduction)
        item.remaining_effort_hrs = max(0.0, item.remaining_effort_hrs - reduction)

    def _apply_critical_path_optimization(self, clone: ProjectState, candidate: RecommendationCandidate) -> None:
        if not candidate.target_ids:
            return
        for item_id in candidate.target_ids:
            item = next((wi for wi in clone.work_items if wi.item_id == item_id), None)
            if not item:
                continue
            reduction = item.current_estimate_hrs * 0.15
            item.current_estimate_hrs = max(1.0, item.current_estimate_hrs - reduction)
            item.remaining_effort_hrs = max(0.0, item.remaining_effort_hrs - reduction)

    # ------------------------------------------------------------------
    # Scoring helpers
    # ------------------------------------------------------------------
    def _find_candidate_by_id(self, recommendation_id: str) -> Optional[RecommendationCandidate]:
        candidates = self._cached_candidates if self._cached_candidates else self.generate_recommendations()
        for candidate in candidates:
            if candidate.recommendation_id == recommendation_id:
                return candidate
        return None

    def _score_candidate(self, candidate: RecommendationCandidate) -> None:
        prob_gain = candidate.expected_probability_gain
        delay_gain = max(0.0, candidate.expected_delay_gain_days)
        risk_gain = max(0.0, candidate.expected_risk_reduction)
        confidence_score = self._confidence_value(candidate.confidence)
        effort_score = self._effort_value(candidate.implementation_effort)

        delay_norm = min(delay_gain / 30.0, 1.0)
        priority = (
            0.35 * prob_gain
            + 0.30 * delay_norm
            + 0.20 * (risk_gain / 100.0)
            + 0.10 * confidence_score
            + 0.05 * effort_score
        )

        candidate.priority_score = max(0.0, min(100.0, priority * 100.0))

    def _confidence_value(self, confidence: str) -> float:
        return {"High": 1.0, "Medium": 0.7, "Low": 0.4}.get(confidence, 0.5)

    def _effort_value(self, effort: str) -> float:
        return {"Low": 1.0, "Medium": 0.6, "High": 0.3}.get(effort, 0.5)

    # ------------------------------------------------------------------
    # Utility and scoring
    # ------------------------------------------------------------------
    def _next_id(self) -> str:
        self.recommendation_counter += 1
        return f"REC-{self.recommendation_counter:03d}"

    def _find_current_sprint(self):
        for sprint in self.project_state.sprints:
            if sprint.status.value == "In Progress":
                return sprint
        for sprint in self.project_state.sprints:
            if sprint.status.value == "Not Started":
                return sprint
        return None

    def _build_skill_demand(self) -> Dict[str, float]:
        demand: Dict[str, float] = {}
        for item in self.project_state.work_items:
            if item.status in {item.status.DONE, item.status.COMPLETED}:
                continue
            demand[item.required_skill] = demand.get(item.required_skill, 0.0) + max(
                item.remaining_effort_hrs, item.current_estimate_hrs
            )
        return demand

    def _build_skill_capacity(self) -> Dict[str, float]:
        capacity: Dict[str, float] = {}
        for resource in self.project_state.team:
            available_hours = resource.availability_pct * resource.allocation_pct * 8.0 * 5.0
            capacity[resource.primary_skill] = capacity.get(resource.primary_skill, 0.0) + available_hours
            if resource.secondary_skill:
                capacity[resource.secondary_skill] = capacity.get(resource.secondary_skill, 0.0) + available_hours * 0.5
        return capacity

    def _suggest_role_for_skill(self, skill: str) -> str:
        roles = [r.role for r in self.project_state.team if r.primary_skill == skill]
        return roles[0] if roles else f"{skill} Engineer"

    def _find_best_skill_level(self, skill: Optional[str]) -> str:
        levels = [r.skill_level.value for r in self.project_state.team if r.primary_skill == skill]
        return levels[0] if levels else "Mid"

    def _find_alternate_resource(self, required_skill: str, current_resource_id: str) -> Optional[Resource]:
        candidates = []
        for resource in self.project_state.team:
            if resource.resource_id == current_resource_id:
                continue
            if required_skill in {resource.primary_skill, resource.secondary_skill} and resource.availability_pct > 0.2:
                candidates.append(resource)
        candidates.sort(key=lambda r: (r.allocation_pct, -r.availability_pct))
        return candidates[0] if candidates else None

    def _descope_score(self, item: WorkItem) -> float:
        priority_value = {
            item.priority.CRITICAL: 0.0,
            item.priority.HIGH: 0.3,
            item.priority.MEDIUM: 0.6,
            item.priority.LOW: 1.0,
        }.get(item.priority, 0.5)
        effort_norm = min(item.current_estimate_hrs / 80.0, 1.0)
        dependency_count = len(self.dag.graph.get(item.item_id, [])) + len(self.dag.reverse_graph.get(item.item_id, []))
        dep_norm = 1.0 - min(dependency_count / 5.0, 1.0)
        return 0.35 * priority_value + 0.30 * effort_norm + 0.25 * dep_norm + 0.10 * (1.0 if item.status == item.status.NOT_STARTED else 0.0)

    def _split_candidate_score(self, item: WorkItem) -> float:
        critical_bonus = 1.0 if item.item_id in self.cp_result.items_on_critical_path else 0.5
        effort_norm = min(item.current_estimate_hrs / 120.0, 1.0)
        dependency_count = len(self.dag.graph.get(item.item_id, [])) + len(self.dag.reverse_graph.get(item.item_id, []))
        dep_norm = min(dependency_count / 5.0, 1.0)
        return 0.40 * critical_bonus + 0.35 * effort_norm + 0.25 * dep_norm

    def _blocker_priority(self, blocker: Blocker) -> float:
        severity_value = {
            blocker.severity.CRITICAL: 1.0,
            blocker.severity.HIGH: 0.8,
            blocker.severity.MEDIUM: 0.5,
            blocker.severity.LOW: 0.2,
        }.get(blocker.severity, 0.4)
        affected_items = len(blocker.impacted_item_ids)
        downstream = self._count_downstream(blocker)
        cp_involvement = self._count_critical_path_involvement(blocker)
        proximity = 1.0 if self._is_blocker_in_current_sprint(blocker) else 0.5
        return (
            0.25 * severity_value
            + 0.20 * min(cp_involvement / max(1, affected_items), 1.0)
            + 0.20 * min(downstream / 10.0, 1.0)
            + 0.20 * min(affected_items / 10.0, 1.0)
            + 0.15 * proximity
        )

    def _blocker_reason(self, blocker: Blocker) -> str:
        downstream = self._count_downstream(blocker)
        cp_items = self._count_critical_path_involvement(blocker)
        return (
            f"Blocks {len(blocker.impacted_item_ids)} items and {downstream} downstream items, "
            f"including {cp_items} on the critical path. "
            f"Severity is {blocker.severity.value}."
        )

    def _count_downstream(self, blocker: Blocker) -> int:
        downstream = 0
        for item_id in blocker.impacted_item_ids:
            downstream += len(self.dag.transitive_closure.get(item_id, []))
        return downstream

    def _count_critical_path_involvement(self, blocker: Blocker) -> int:
        return sum(1 for item_id in blocker.impacted_item_ids if item_id in self.cp_result.items_on_critical_path)

    def _is_blocker_in_current_sprint(self, blocker: Blocker) -> bool:
        if not self.current_sprint:
            return False
        sprint_id = self.current_sprint.sprint_id
        sprint_name = self.current_sprint.sprint_name
        for item_id in blocker.impacted_item_ids:
            work_item = self.work_items.get(item_id)
            if not work_item:
                continue
            if work_item.assigned_sprint in {sprint_id, sprint_name}:
                return True
        return False
